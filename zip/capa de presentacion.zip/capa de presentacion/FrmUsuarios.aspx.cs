﻿using System;
using System.Web.UI;
using SoporteTecnico.CapaNegocio;

namespace SoporteTecnico.CapaPresentacion
{
    public partial class FrmUsuarios : System.Web.UI.Page
    {
        UsuarioBLL usuarioBLL = new UsuarioBLL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LlenarGrid();
            }
        }

        protected void LlenarGrid()
        {
            GridView1.DataSource = usuarioBLL.ObtenerUsuarios();
            GridView1.DataBind();
        }

        protected void Bagregar_Click(object sender, EventArgs e)
        {
            usuarioBLL.InsertarUsuario(Tnombre.Text, Tcorreo.Text, Ttelefono.Text, Tclave.Text);
            LlenarGrid();
        }

        protected void Bmodificar_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(Tcodigo.Text);
            usuarioBLL.ModificarUsuario(id, Tnombre.Text, Tcorreo.Text, Ttelefono.Text, Tclave.Text);
            LlenarGrid();
        }

        protected void Bborrar_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(Tcodigo.Text);
            usuarioBLL.EliminarUsuario(id);
            LlenarGrid();
        }
    }
}
