﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using proyecto_proga.CapaNegocio;

namespace proyecto_proga.CapaPresentacion
{
    public partial class FrmTecnico : System.Web.UI.Page
    {
        TecnicoBLL tecnicoBLL = new TecnicoBLL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LlenarGrid();
            }
        }

        protected void LlenarGrid()
        {
            try
            {
                TecnicoBLL tecnicoBLL = new TecnicoBLL();
                GridView1.DataSource = tecnicoBLL.ObtenerTecnicos();
                GridView1.DataBind();
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error al cargar los datos: " + ex.Message + "');</script>");
            }
        }

        protected void Bagregar_Click(object sender, EventArgs e)
        {
            try
            {
                TecnicoBLL tecnicoBLL = new TecnicoBLL();

                LlenarGrid();

                Tnombre.Text = "";
                Tespecialidad.Text = "";
                Ttelefono.Text = "";

                Response.Write("<script>alert('Tecnico agregado correctamente';</script>");

                tecnicoBLL.InsertarTecnico(Tnombre.Text, Tespecialidad.Text, Ttelefono.Text);
                LlenarGrid();
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error al agregar técnico: " + ex.Message + "');</script>");
            }
        }

        protected void Bmodificar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(Tcodigo.Text);
                tecnicoBLL.ModificarTecnico(id, Tnombre.Text, Tespecialidad.Text, Ttelefono.Text);
                LlenarGrid();
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error al modificar técnico: " + ex.Message + "');</script>");
            }
        }

        protected void Bborrar_Click(object sender, EventArgs e)
        {
            try
            {
                // 🔹 CORRECCIÓN: La condición debe ser if (string.IsNullOrEmpty(Tcodigo.Text))
                if (string.IsNullOrEmpty(Tcodigo.Text))
                {
                    Response.Write("<script>alert('Debe ingresar un código');</script>");
                    return;
                }

                int id = Convert.ToInt32(Tcodigo.Text);
                tecnicoBLL.EliminarTecnico(id);
                LlenarGrid();

                // Opcional: Limpiar los campos después de eliminar
                Tcodigo.Text = "";
                Tnombre.Text = "";
                Tespecialidad.Text = "";
                Ttelefono.Text = "";
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error al eliminar técnico: " + ex.Message + "');</script>");
            }
        }
    }
}


