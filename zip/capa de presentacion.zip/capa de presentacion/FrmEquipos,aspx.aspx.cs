﻿using System;
using System.Web.UI;
using proyecto_proga.CapaNegocio;

namespace proyecto_proga.CapaPresentacion
{
    public partial class FrmEquipos : System.Web.UI.Page
    {
        EquiposBLL equiposBLL = new EquiposBLL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LlenarGrid();
            }
        }

        protected void LlenarGrid()
        {
            GridView1.DataSource = equiposBLL.ObtenerEquipos();
            GridView1.DataBind();
        }

        protected void Bagregar_Click(object sender, EventArgs e)
        {
            equiposBLL.InsertarEquipo(TtipoEquipo.Text, Tmodelo.Text, Convert.ToInt32(TusuarioID.Text));
            LlenarGrid();
        }

        protected void Bmodificar_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(Tcodigo.Text);
            equiposBLL.ModificarEquipo(id, TtipoEquipo.Text, Tmodelo.Text, Convert.ToInt32(TusuarioID.Text));
            LlenarGrid();
        }

        protected void Bborrar_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(Tcodigo.Text);
            equiposBLL.EliminarEquipo(id);
            LlenarGrid();
        }
    }
}
