﻿using System.Data;
using proyecto_proga.CapaDatos;  // ✅ Referencia correcta a CapaDatos

namespace proyecto_proga.CapaNegocio
{
    public class TecnicoBLL
    {
        TecnicoDAL tecnicoDAL = new TecnicoDAL(); // ✅ Instancia de CapaDatos

        public DataTable ObtenerTecnicos()
        {
            return tecnicoDAL.ObtenerTecnicos();
        }

        public void InsertarTecnico(string nombre, string especialidad, string telefono)
        {
            tecnicoDAL.InsertarTecnico(nombre, especialidad, telefono);
        }

        public void ModificarTecnico(int id, string nombre, string especialidad, string telefono)
        {
            tecnicoDAL.ModificarTecnico(id, nombre, especialidad, telefono);
        }

        public void EliminarTecnico(int id)
        {
            tecnicoDAL.EliminarTecnico(id);
        }
    }
}
