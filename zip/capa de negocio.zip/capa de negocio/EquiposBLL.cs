﻿using System.Data;
using proyecto_proga.CapaDatos;

namespace proyecto_proga.CapaNegocio
{
    public class EquiposBLL
    {
        EquiposDAL equiposDAL = new EquiposDAL();

        public DataTable ObtenerEquipos()
        {
            return equiposDAL.ObtenerEquipos();
        }

        public void InsertarEquipo(string tipoEquipo, string modelo, int usuarioID)
        {
            equiposDAL.InsertarEquipo(tipoEquipo, modelo, usuarioID);
        }

        public void ModificarEquipo(int id, string tipoEquipo, string modelo, int usuarioID)
        {
            equiposDAL.ModificarEquipo(id, tipoEquipo, modelo, usuarioID);
        }

        public void EliminarEquipo(int id)
        {
            equiposDAL.EliminarEquipo(id);
        }
    }
}
