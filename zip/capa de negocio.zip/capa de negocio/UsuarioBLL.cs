﻿using System.Data;
using SoporteTecnico.CapaDatos;

namespace SoporteTecnico.CapaNegocio
{
    public class UsuarioBLL
    {
        UsuarioDAL usuarioDAL = new UsuarioDAL();

        public DataTable ObtenerUsuarios()
        {
            return usuarioDAL.ObtenerUsuarios();
        }

        public void InsertarUsuario(string nombre, string correo, string telefono, string clave)
        {
            usuarioDAL.InsertarUsuario(nombre, correo, telefono, clave);
        }

        public void ModificarUsuario(int id, string nombre, string correo, string telefono, string clave)
        {
            usuarioDAL.ModificarUsuario(id, nombre, correo, telefono, clave);
        }

        public void EliminarUsuario(int id)
        {
            usuarioDAL.EliminarUsuario(id);
        }
    }
}
