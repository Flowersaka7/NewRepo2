﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace proyecto_proga.CapaDatos
{
    public class TecnicoDAL
    {
        private string connectionString = ConfigurationManager.ConnectionStrings["conexion"].ConnectionString;

        // Método para obtener técnicos (Usa procedimiento almacenado)
        public DataTable ObtenerTecnicos()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_ObtenerTecnicos", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Método para insertar un técnico (Usa procedimiento almacenado)
        public void InsertarTecnico(string nombre, string especialidad, string telefono)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_InsertarTecnico", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Nombre", nombre);
                    cmd.Parameters.AddWithValue("@Especialidad", especialidad);
                    cmd.Parameters.AddWithValue("@Telefono", telefono);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Método para modificar un técnico (Usa procedimiento almacenado)
        public void ModificarTecnico(int id, string nombre, string especialidad, string telefono)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_ModificarTecnico", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", id);
                    cmd.Parameters.AddWithValue("@Nombre", nombre);
                    cmd.Parameters.AddWithValue("@Especialidad", especialidad);
                    cmd.Parameters.AddWithValue("@Telefono", telefono);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Método para eliminar un técnico (Usa procedimiento almacenado)
        public void EliminarTecnico(int ID)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_EliminarTecnico", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", ID);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}




